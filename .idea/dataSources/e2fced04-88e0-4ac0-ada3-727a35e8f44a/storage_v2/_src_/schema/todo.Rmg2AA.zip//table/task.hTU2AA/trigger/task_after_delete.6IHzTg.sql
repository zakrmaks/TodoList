create definer = root@localhost trigger task_AFTER_DELETE
    after delete
    on task
    for each row
BEGIN
	/* можно было упаковать все условия в один if-else, но тогда он становится не очень читабельным */

    /*  категория НЕПУСТАЯ                 и        статус задачи ЗАВЕРШЕН */
    if (ifnull(old.category_id, 0)>0       &&       ifnull(old.completed, 0)=1) then
		update tasklist.category set completed_count = (ifnull(completed_count, 0)-1) where id = old.category_id;
	end if;
    
	/*  категория НЕПУСТАЯ                и         статус задачи НЕЗАВЕРШЕН */
    if (ifnull(old.category_id, 0)>0      &&        ifnull(old.completed, 0)=0) then
		update tasklist.category set uncompleted_count = (ifnull(uncompleted_count, 0)-1) where id = old.category_id;
	end if;
    
    
    
    /* общая статистика */
	if ifnull(old.completed, 0)=1 then
		update tasklist.stat set completed_total = (ifnull(completed_total, 0)-1)  where id=1;
	else
		update tasklist.stat set uncompleted_total = (ifnull(uncompleted_total, 0)-1)  where id=1;
    end if;
    
END;


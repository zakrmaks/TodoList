create definer = root@localhost trigger task_AFTER_INSERT
    after insert
    on task
    for each row
BEGIN

	/* можно было упаковать все условия в один if-else, но тогда он становится не очень читабельным */
    
    /*  категория НЕПУСТАЯ                и       статус задачи ЗАВЕРШЕН */
    if (ifnull(NEW.category_id, 0)>0      &&      ifnull(NEW.completed, 0)=1) then
		update tasklist.category set completed_count = (ifnull(completed_count, 0)+1) where id = NEW.category_id;
	end if;
    
	/*  категория НЕПУСТАЯ                 и       статус задачи НЕЗАВЕРШЕН */
    if (ifnull(NEW.category_id, 0)>0      &&      ifnull(NEW.completed, 0)=0) then
		update tasklist.category c set uncompleted_count = (ifnull(uncompleted_count, 0)+1) where id = NEW.category_id;
	end if;
    

    /* общая статистика */
	if ifnull(NEW.completed, 0)=1 then
		update tasklist.stat set completed_total = (ifnull(completed_total, 0)+1)  where id=1;
	else
		update tasklist.stat set uncompleted_total = (ifnull(uncompleted_total, 0)+1)  where id=1;
    end if;

END;


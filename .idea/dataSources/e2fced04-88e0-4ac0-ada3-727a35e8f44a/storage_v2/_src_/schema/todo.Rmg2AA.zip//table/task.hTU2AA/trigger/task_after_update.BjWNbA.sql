create definer = root@localhost trigger task_AFTER_UPDATE
    after update
    on task
    for each row
BEGIN
    
  
  /* изменили completed на 1, НЕ изменили категорию */
    IF (   ifnull(old.completed,0) <> ifnull(new.completed,0)  &&   new.completed=1      &&   ifnull(old.category_id,0) = ifnull(new.category_id,0)     ) THEN    
    
		/* у категории кол-во незавершенных уменьшится на 1,  кол-во завершенных увеличится на 1 */
		update tasklist.category set uncompleted_count = (ifnull(uncompleted_count, 0)-1), completed_count = (ifnull(completed_count,0)+1) where id = old.category_id; 
        
        /* общая статистика */
		update tasklist.stat set uncompleted_total = (ifnull(uncompleted_total,0)-1), completed_total = (ifnull(completed_total,0)+1)  where id=1;

        
	END IF;
    
    
    /* изменили completed на 0, НЕ изменили категорию */
    IF (   ifnull(old.completed,0) <> ifnull(new.completed,0)    &&   new.completed=0       &&   ifnull(old.category_id,0) = ifnull(new.category_id,0)   ) THEN    
    
		/* у категории кол-во завершенных уменьшится на 1, кол-во незавершенных увеличится на 1 */
		update tasklist.category set completed_count = (ifnull(completed_count,0)-1), uncompleted_count = (ifnull(uncompleted_count,0)+1) where id = old.category_id; 
       
       /* общая статистика */
		update tasklist.stat set completed_total = (ifnull(completed_total,0)-1), uncompleted_total = (ifnull(uncompleted_total,0)+1)  where id=1;

       
	END IF;
    
    
    
	/* изменили категорию для неизмененного completed=1 */
    IF (   ifnull(old.completed,0) = ifnull(new.completed,0)    &&   new.completed=1       &&   ifnull(old.category_id,0) <> ifnull(new.category_id,0)    ) THEN    
    
		/* у старой категории кол-во завершенных уменьшится на 1 */
		update tasklist.category set completed_count = (ifnull(completed_count,0)-1) where id = old.category_id; 

        
		/* у новой категории кол-во завершенных увеличится на 1 */
		update tasklist.category set completed_count = (ifnull(completed_count,0)+1) where id = new.category_id; 
	
    
		/* общая статистика не изменяется */
       
	END IF;
    
    
    
    
        
    /* изменили категорию для неизменнеого completed=0 */
    IF (   ifnull(old.completed,0) = ifnull(new.completed,0)     &&   new.completed=0      &&   ifnull(old.category_id,0) <> ifnull(new.category_id,0)     ) THEN    
    
		/* у старой категории кол-во незавершенных уменьшится на 1 */
		update tasklist.category set uncompleted_count = (ifnull(uncompleted_count,0)-1) where id = old.category_id; 

		/* у новой категории кол-во незавершенных увеличится на 1 */
		update tasklist.category set uncompleted_count = (ifnull(uncompleted_count,0)+1) where id = new.category_id; 
       
       /* общая статистика не изменяется */
       
	END IF;
    
    
    
    
    
	
    /* изменили категорию, изменили completed с 1 на 0 */
    IF (   ifnull(old.completed,0) <> ifnull(new.completed,0)     &&   new.completed=0      &&   ifnull(old.category_id,0) <> ifnull(new.category_id,0)     ) THEN    
    
		/* у старой категории кол-во завершенных уменьшится на 1 */
		update tasklist.category set completed_count = (ifnull(completed_count,0)-1) where id = old.category_id; 
        
		/* у новой категории кол-во незавершенных увеличится на 1 */
		update tasklist.category set uncompleted_count = (ifnull(uncompleted_count,0)+1) where id = new.category_id; 


		/* общая статистика */
		update stat set uncompleted_total = (ifnull(uncompleted_total,0)+1), completed_total = (ifnull(completed_total,0)-1)  where id=1;

       
	END IF;
    
    
            
    /* изменили категорию, изменили completed с 0 на 1 */
    IF (   ifnull(old.completed,0) <> ifnull(new.completed,0)     &&   new.completed=1      &&   ifnull(old.category_id,0) <> ifnull(new.category_id,0)     ) THEN    
    
		/* у старой категории кол-во незавершенных уменьшится на 1 */
		update tasklist.category set uncompleted_count = (ifnull(uncompleted_count,0)-1) where id = old.category_id; 
        
		/* у новой категории кол-во завершенных увеличится на 1 */
		update tasklist.category set completed_count = (ifnull(completed_count,0)+1) where id = new.category_id; 
        
        /* общая статистика */
		update tasklist.stat set uncompleted_total = (ifnull(uncompleted_total,0)-1), completed_total = (ifnull(completed_total,0)+1)  where id=1;
	
	END IF;
    
    
    
END;

